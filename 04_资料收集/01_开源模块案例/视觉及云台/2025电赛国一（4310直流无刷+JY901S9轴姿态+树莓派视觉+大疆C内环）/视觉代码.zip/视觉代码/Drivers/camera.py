import cv2 as cv
import importlib
from picamera2 import Picamera2

Picamera2.set_logging(Picamera2.WARNING)


class Camera:
    def __init__(self):
        # 检测Picamera2支持
        self.picam2 = None
        self.cvcap = None
        self.is_opened = False

    def open(self, main_size=(640, 360)):
        # 如果摄像头已经打开，则直接返回True
        if self.is_opened: return True

        try:
            # 创建Picamera2对象
            self.picam2 = Picamera2()
            # 创建视频配置
            config = self.picam2.create_video_configuration(
                main={"size": main_size, 'format': 'BGR888'},
                controls={"FrameRate": 90}
            )
            # 配置摄像头
            self.picam2.configure(config)
            # 启动摄像头
            self.picam2.start()
            # 设置摄像头已打开标志
            self.is_opened = True
            return True

        except Exception as e:
            # 打印摄像头打开失败的错误信息
            print(f"Camera Open Failed: {str(e)}")
            # 设置摄像头未打开标志
            self.is_opened = False
            return False

    def capture(self, resize=None):
        # 如果摄像头未打开，则返回None
        if not self.is_opened: return None

        try:
            # 如果使用picamera2，则捕获图像
            frame = self.picam2.capture_array()
            # 如果捕获到的图像不为空且维度为3，则将其转换为BGR格式
            if frame is not None and frame.ndim == 3:
                frame = cv.cvtColor(frame, cv.COLOR_RGBA2BGR)
            # 添加图像旋转180度的代码
            frame = cv.rotate(frame, cv.ROTATE_180)
            # 调整大小（如BlackSearch中使用的640x480）
            if resize and isinstance(resize, tuple) and len(resize) == 2:
                frame = cv.resize(frame, resize)
            # 返回捕获到的图像
            return frame
        # 捕获异常并打印错误信息
        except Exception as e:
            print(f"Image Capture Failed: {str(e)}")
            # 返回None
            return None

    def close(self):
        if self.is_opened:
            self.picam2.stop()
            self.is_opened = False

    def __del__(self):
        # 确保对象销毁时释放资源
        self.close()
